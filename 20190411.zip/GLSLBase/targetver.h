#pragma once

#include <SDKDDKVer.h>
